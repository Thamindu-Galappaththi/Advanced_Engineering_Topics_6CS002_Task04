package com.wlv.reflection;

import java.lang.Double;

public class reflection_2 {
	
  public static void main(String[] args) {
    Simple s = new Simple();
    s.traingleB();
    
  // s.squareB();
    double b = s.b;
  
  // double b = s.b; 
    System.out.println("s=" + s);
  }
}



